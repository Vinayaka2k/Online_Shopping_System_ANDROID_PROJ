package com.example.new_proj;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class signin extends AppCompatActivity {
SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
    }

    public void sign_in(View v)
    {
        db = openOrCreateDatabase("database" , Context.MODE_PRIVATE , null);
        EditText et1 = (EditText)findViewById(R.id.u1);
        EditText et2 = (EditText)findViewById(R.id.p1);
        Cursor c1 = db.rawQuery("SELECT * FROM signup_table WHERE uname='"+et1.getText()+"'", null);
        c1.moveToFirst();
        if(c1.getCount() == 0)
        {
            String err = "Username does not exists!!";
            Toast.makeText(getApplicationContext(), err, Toast.LENGTH_LONG).show();

        }
        else{
            String pass = c1.getString(1);
            if(et2.getText().toString().equals(pass))
            {
                String res = "Signed In!!";
                Toast.makeText(getApplicationContext(), res, Toast.LENGTH_LONG).show();
            }
            else
            {
                String err1 = "Username  and passwords do not match!!";
                Toast.makeText(getApplicationContext(),err1,Toast.LENGTH_LONG).show();
            }

        }
        db.close();
    }
}
