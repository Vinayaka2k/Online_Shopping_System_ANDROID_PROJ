package com.example.new_proj;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity
{

    EditText ed2;
    EditText ed1;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void navigation(View n)
    {
        Intent ob = new Intent(MainActivity.this,nav_bar.class);
        startActivity(ob);
    }


    public void signin_page(View b)
    {
        Intent obj = new Intent(MainActivity.this,signin.class);
        startActivity(obj);
    }

    public void signup(View v)
    {
        ed1 = findViewById(R.id.uname1);
        ed2 = findViewById(R.id.pwd1);
        db = openOrCreateDatabase("database" , Context.MODE_PRIVATE , null);
        db.execSQL("CREATE TABLE IF NOT EXISTS signup_table(uname VARCHAR , pwd VARCHAR);");
        Cursor c1 = db.rawQuery("SELECT * FROM signup_table WHERE uname='"+ed1.getText()+"'", null);
        if(c1.getCount() !=0)
        {
            String err = "Username " +ed1.getText()+" already exists!!";
            Toast.makeText(getApplicationContext(), err, Toast.LENGTH_SHORT).show();
        }
        else {
            db.execSQL("INSERT INTO signup_table VALUES('" + ed1.getText() + "','" + ed2.getText() +
                    "');");
            Cursor c = db.rawQuery("SELECT * FROM signup_table", null);
            String res;
            while (c.moveToNext()) {
                String un = c.getString(0);
                String pw = c.getString(1);
                res = un + pw;
                Toast.makeText(getApplicationContext(), res, Toast.LENGTH_LONG).show();
            }
        }
        db.close();
    }
}
