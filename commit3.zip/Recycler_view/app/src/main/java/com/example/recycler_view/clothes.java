package com.example.recycler_view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class clothes extends AppCompatActivity {

    List<Book> book1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clothes);
        book1 = new ArrayList<>();
        book1.add(new Book("DENIM JEANS","PANTS","Desc1",R.drawable.denim_jeans));
        book1.add(new Book("PEARLS OCEAN WHITE","SHIRT","Desc 2",R.drawable.pearl_ocean_white));
        book1.add(new Book("UD FABRIC","SHIRT","Desc 3",R.drawable.udfabric));
        book1.add(new Book("RK TRENDS","T SHIRT","Desc 4",R.drawable.rktrends));
        book1.add(new Book("RIDING JEANS","PANTS","Desc 5",R.drawable.riding));
        book1.add(new Book("RED BROWN SHIRT","SHIRT","Desc 6",R.drawable.redbrown));
        book1.add(new Book("RED SHIRT","SHIRT","Desc 7",R.drawable.red));
        book1.add(new Book("BROWN JEANS","PANTS","Desc 8",R.drawable.jeansbrown));
        book1.add(new Book("BLACK COTTON","SHIRT","Desc 9",R.drawable.black_satin));
        book1.add(new Book("PEARL RED SHIRT","SHIRT","Desc 10",R.drawable.pearlred));

        RecyclerView myrv = (RecyclerView)findViewById(R.id.recyclerview_id);
        RecyclerViewAdapter myAdapter  = new RecyclerViewAdapter(this,book1);
        myrv.setLayoutManager(new GridLayoutManager(this,3));
        myrv.setAdapter(myAdapter);
    }
}
