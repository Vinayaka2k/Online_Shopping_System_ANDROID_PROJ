package com.example.recycler_view;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class title1 extends AppCompatActivity {

    ImageView im;
    TextView title,desc,cat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_title1);

        // receive data

        Intent obj = getIntent();
        String Title = obj.getExtras().getString("Title");
        String Category = obj.getExtras().getString("Category");
        String Description = obj.getExtras().getString("Description");
        int Thumbnail = obj.getExtras().getInt("Thumbnail");

        title = (TextView)findViewById(R.id.title_id);
        desc = (TextView)findViewById(R.id.desc_id);
        im = (ImageView)findViewById(R.id.bookthumbnail);
        cat = (TextView)findViewById(R.id.category_id);


        title.setText(Title);
        desc.setText(Description);
        cat.setText(Category);
        im.setImageResource(Thumbnail);

    }
}
