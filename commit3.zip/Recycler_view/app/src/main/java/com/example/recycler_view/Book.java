package com.example.recycler_view;

public class Book
{
    private String Title,Category,Description;
    private int Thumbnail;

    //setters

    public Book(String title, String category, String description, int thumbnail)
    {
        Title = title;
        Category = category;
        Description = description;
        Thumbnail = thumbnail;
    }
    // getters
    public String getTitle() {
        return Title;
    }

    public String getCategory() {
        return Category;
    }

    public String getDescription() {
        return Description;
    }

    public int getThumbnail() {
        return Thumbnail;
    }

}
