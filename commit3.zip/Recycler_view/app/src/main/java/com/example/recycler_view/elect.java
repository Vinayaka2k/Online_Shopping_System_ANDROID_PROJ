package com.example.recycler_view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class elect extends AppCompatActivity {

    List<Book> book1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clothes);
        book1 = new ArrayList<>();
        book1.add(new Book("DELL INSPIRON","LAPTOPS","Desc1",R.drawable.dell_inspiron));
        book1.add(new Book("HONOR 7C","MOBILES","Desc 2",R.drawable.honor_7c));
        book1.add(new Book("HP PAVILION","LAPTOPS","Desc 3",R.drawable.hp_pavilion));
        book1.add(new Book("LENOVO IDEAPAD","LAPTOPS","Desc 4",R.drawable.lenovo_ideapad));
        book1.add(new Book("MI Y2","MOBILES","Desc 5",R.drawable.mi_y2));
        book1.add(new Book("MI 6 PRO","MOBILES","Desc 6",R.drawable.mi6pro));
        book1.add(new Book("MICROMAX NEO","LAPTOPS","Desc 7",R.drawable.micromax_neo));
        book1.add(new Book("GALAXY M10","LAPTOPS","Desc 8",R.drawable.sam_galaxy_m10));
        book1.add(new Book("SONY BRAVIA","TELEVISION","Desc 9",R.drawable.sony_bravia));
        book1.add(new Book("MI LED TV 4A","TELEVISION","Desc 9",R.drawable.mi_ledtv_4a));
        RecyclerView myrv = (RecyclerView)findViewById(R.id.recyclerview_id);
        RecyclerViewAdapter myAdapter  = new RecyclerViewAdapter(this,book1);
        myrv.setLayoutManager(new GridLayoutManager(this,3));
        myrv.setAdapter(myAdapter);
    }
}
