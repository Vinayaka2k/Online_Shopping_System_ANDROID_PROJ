package com.example.recycler_view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class food extends AppCompatActivity {

    List<Book> book1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clothes);
        book1 = new ArrayList<>();
        book1.add(new Book("VADA","FOOD","Desc 2",R.drawable.vada));
        book1.add(new Book("SAMOSA","FOOD","Desc 3",R.drawable.samosa));
        book1.add(new Book("SANDWITCH","FOOD","Desc 4",R.drawable.sandwitch));
        book1.add(new Book("ROTI","FOOD","Desc 5",R.drawable.roti));
        book1.add(new Book("FANTA","DRINKS","Desc 9",R.drawable.fanta));
        book1.add(new Book("BURGER","FOOD","Desc 6",R.drawable.burger));
        book1.add(new Book("PIZZA","FOOD","Desc 7",R.drawable.pizza));
        book1.add(new Book("SALAD","FOOD","Desc 8",R.drawable.salad));
        book1.add(new Book("FRENCH FRIES","FOOD","Desc 9",R.drawable.frenchfries));
        book1.add(new Book("COKE","FOOD","Desc 9",R.drawable.coke));
        RecyclerView myrv = (RecyclerView)findViewById(R.id.recyclerview_id);
        RecyclerViewAdapter myAdapter  = new RecyclerViewAdapter(this,book1);
        myrv.setLayoutManager(new GridLayoutManager(this,3));
        myrv.setAdapter(myAdapter);
    }
}
